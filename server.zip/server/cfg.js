module.exports = {
	secret : 'visit matchyourtie.com!', //jwt secret
	db: {
		local: 'mongodb://localhost:27017/grocerybot',
		remote: ''
	}
}